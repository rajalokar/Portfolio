// Year in footer
document.getElementById("year").textContent = new Date().getFullYear();

// Contact form: open default mail app with pre-filled message (no backend needed)
function sendMessage(e){
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const msg = document.getElementById("message").value.trim();

  const subject = encodeURIComponent(`Portfolio Inquiry from ${name}`);
  const body = encodeURIComponent(
    `Hi Alok,\n\n${msg}\n\n— ${name}\n${email}`
  );
  const mailto = `mailto:alokofficialarrah@gmail.com?subject=${subject}&body=${body}`;
  window.location.href = mailto;

  const status = document.getElementById("form-status");
  status.textContent = "Thanks! Your email draft is ready to send.";
  setTimeout(()=> status.textContent = "", 6000);
  return false;
}
function openTab(tabName) {
  const contents = document.querySelectorAll(".tab-content");
  const tabs = document.querySelectorAll(".tab-links");

  contents.forEach(c => c.classList.remove("active-tab"));
  tabs.forEach(t => t.classList.remove("active-link"));

  document.getElementById(tabName).classList.add("active-tab");
  event.target.classList.add("active-link");
}
